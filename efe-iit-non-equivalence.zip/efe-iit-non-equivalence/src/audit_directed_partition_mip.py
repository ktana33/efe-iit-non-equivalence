#!/usr/bin/env python3
"""Exhaustive directed-set-partition audit for the canonical n-cycle.

Enumerates distinct directed cut matrices for n = 2,...,8 and verifies the
minimum-information-partition result reported in the manuscript. No figures
are generated.
"""

from __future__ import annotations

import csv
import itertools
import math
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

import pyphi.combinatorics as combinatorics

OUTDIR = ROOT / "results"
OUTDIR.mkdir(parents=True, exist_ok=True)
MAX_N = 8

CAUSE = 0
EFFECT = 1
BIDIRECTIONAL = 2
DIRECTIONS = (CAUSE, EFFECT, BIDIRECTIONAL)


def edge_bit(n: int, source: int, target: int) -> int:
    return 1 << (source * n + target)


def add_directed_complete_cut(mask: int, n: int, sources, targets) -> int:
    for source in sources:
        for target in targets:
            if source != target:
                mask |= edge_bit(n, source, target)
    return mask


def cycle_edge_mask(n: int) -> int:
    """Actual causal edges for source_for_target=(1,2,...,n-1,0)."""
    mask = 0
    for target in range(n):
        source = (target + 1) % n
        mask |= edge_bit(n, source, target)
    return mask


def directed_partition_masks(n: int):
    """Mirror PyPhi's DIRECTED_SET_PARTITION cut-matrix construction."""
    nodes = set(range(n))
    partitions = combinatorics.set_partitions(list(range(n)), nontrivial=True)
    seen = set()

    for partition in partitions:
        for directions in itertools.product(DIRECTIONS, repeat=len(partition)):
            mask = 0
            for part, direction in zip(partition, directions):
                part = set(part)
                nonpart = nodes - part
                if direction == CAUSE:
                    mask = add_directed_complete_cut(mask, n, nonpart, part)
                elif direction == EFFECT:
                    mask = add_directed_complete_cut(mask, n, part, nonpart)
                else:
                    mask = add_directed_complete_cut(mask, n, nonpart, part)
                    mask = add_directed_complete_cut(mask, n, part, nonpart)

            if mask not in seen:
                seen.add(mask)
                yield mask


def analyze_n(n: int) -> dict[str, object]:
    actual_cycle = cycle_edge_mask(n)
    unique_count = 0
    zero_actual_cut_count = 0
    min_k = math.inf
    best_ratio = math.inf
    best_pairs = set()
    best_count = 0
    max_m_for_k: dict[int, int] = {}
    tol = 1e-15

    for mask in directed_partition_masks(n):
        unique_count += 1
        m = mask.bit_count()
        k = (mask & actual_cycle).bit_count()

        if k == 0:
            zero_actual_cut_count += 1
            continue

        min_k = min(min_k, k)
        max_m_for_k[k] = max(max_m_for_k.get(k, 0), m)
        ratio = k / m

        if ratio < best_ratio - tol:
            best_ratio = ratio
            best_pairs = {(k, m)}
            best_count = 1
        elif abs(ratio - best_ratio) <= tol:
            best_pairs.add((k, m))
            best_count += 1

    predicted_m2 = math.floor(4 * n * n / 7)
    return {
        "n": n,
        "unique_cut_matrices": unique_count,
        "zero_actual_cut_partitions": zero_actual_cut_count,
        "minimum_actual_edges_cut": int(min_k),
        "best_normalized_ratio": best_ratio,
        "best_k_M_pairs": sorted(best_pairs),
        "number_best_masks": best_count,
        "max_M_for_k1": max_m_for_k.get(1),
        "max_M_for_k2": max_m_for_k.get(2),
        "predicted_floor_4n2_over_7": predicted_m2,
        "k2_formula_matches": max_m_for_k.get(2) == predicted_m2,
    }


def main() -> None:
    rows = []
    for n in range(2, MAX_N + 1):
        print(f"n={n}: enumerating...", flush=True)
        row = analyze_n(n)
        rows.append(row)
        print(
            f"  cuts={row['unique_cut_matrices']}, "
            f"best={row['best_k_M_pairs']}, "
            f"floor(4n^2/7)={row['predicted_floor_4n2_over_7']}"
        )

    for row in rows:
        n = int(row["n"])
        assert row["zero_actual_cut_partitions"] == 0
        assert row["minimum_actual_edges_cut"] >= 1
        assert row["k2_formula_matches"]
        if n >= 3:
            expected = [(2, math.floor(4 * n * n / 7))]
            assert row["best_k_M_pairs"] == expected

    out = OUTDIR / "directed_partition_mip_audit_n2_n8.csv"
    fieldnames = list(rows[0].keys())
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("All assertions PASS for n=2..8")
    print(f"CSV written to: {out}")


if __name__ == "__main__":
    main()
