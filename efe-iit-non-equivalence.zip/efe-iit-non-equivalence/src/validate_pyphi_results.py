#!/usr/bin/env python3
"""Numerical validation for the manuscript.

This script reproduces the PyPhi checks reported for noisy permutation
networks with n = 2--5. It intentionally generates numerical CSV files only;
no manuscript figures are produced.

Run this script from any directory. It changes the working directory to the
repository root before importing PyPhi so that the bundled pyphi_config.yml is
loaded automatically.
"""

from __future__ import annotations

import math
import os
from itertools import permutations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

import numpy as np
import pandas as pd
from scipy.optimize import brentq
import pyphi
from pyphi.substrate import Substrate

OUTDIR = ROOT / "results"
OUTDIR.mkdir(parents=True, exist_ok=True)

EXPECTED_PYPHI_VERSION = "2.1.dev1707+g1f47a1e20"
EXPECTED_PYPHI_COMMIT = "1f47a1e20b6a27fd92c25ec4e8a1aa5e829f8198"


def h2(p: float) -> float:
    """Binary entropy in bits."""
    if p <= 0.0 or p >= 1.0:
        return 0.0
    return -p * math.log2(p) - (1.0 - p) * math.log2(1.0 - p)


def state_risk_uniform_g2(n: int, eta: float) -> float:
    """Fully observed state-risk EFE with uniform future-state preferences."""
    return n * (1.0 - h2(eta))


def analytical_n_cycle(n: int, eta: float) -> dict[str, float]:
    """Closed-form revised-IIT quantities for a noisy single n-cycle."""
    p = eta**n
    i_diff = -n * math.log2(eta)
    i_spec = n * eta**n * math.log2(2.0 * eta)
    phi_partition = 2.0 * eta**n * math.log2(2.0 * eta)
    ii = min(i_diff, i_spec)
    phi_s = min(phi_partition, ii)
    return {
        "p": p,
        "i_diff": i_diff,
        "i_spec": i_spec,
        "phi_partition": phi_partition,
        "ii": ii,
        "phi_s": phi_s,
    }


def eta_star(n: int) -> float:
    """Unique solution of D_n(eta) = A_n(eta) on (1/2, 1)."""
    def f(eta: float) -> float:
        a = analytical_n_cycle(n, eta)
        return a["i_diff"] - a["phi_partition"]

    return float(brentq(f, 0.5000000001, 0.9999999999, xtol=1e-14))


def state_from_index(index: int, n: int) -> tuple[int, ...]:
    # PyPhi binary state order uses node 0 as the least-significant bit.
    return tuple((index >> j) & 1 for j in range(n))


def permutation_tpm(source_for_target: tuple[int, ...], eta: float) -> np.ndarray:
    """TPM for Y_i <- X_source_for_target[i] with noisy-copy reliability eta."""
    n = len(source_for_target)
    tpm = np.empty((2**n, n), dtype=float)
    for row in range(2**n):
        x = state_from_index(row, n)
        for target, source in enumerate(source_for_target):
            tpm[row, target] = eta if x[source] == 1 else 1.0 - eta
    return tpm


def permutation_cm(source_for_target: tuple[int, ...]) -> np.ndarray:
    """Connectivity matrix using PyPhi convention cm[source, target] = 1."""
    n = len(source_for_target)
    cm = np.zeros((n, n), dtype=int)
    for target, source in enumerate(source_for_target):
        cm[source, target] = 1
    return cm


def safe_float(value) -> float:
    if value is None:
        return float("nan")
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def direction_value(mapping, target: str) -> float:
    if mapping is None:
        return float("nan")
    for key, value in mapping.items():
        if str(key).upper().endswith(target):
            return safe_float(value)
    return float("nan")


def analyze(source_for_target: tuple[int, ...], eta: float) -> dict[str, object]:
    n = len(source_for_target)
    substrate = Substrate(
        permutation_tpm(source_for_target, eta),
        cm=permutation_cm(source_for_target),
    )
    analysis = pyphi.analyze(
        substrate,
        tuple([1] * n),
        subset=tuple(range(n)),
        formalism="IIT_4_0_2026",
    )
    sia = analysis.sia
    cause = getattr(sia, "cause", None)
    effect = getattr(sia, "effect", None)
    idiff = getattr(sia, "intrinsic_differentiation", None)
    return {
        "phi_s": safe_float(analysis.phi),
        "phi_c": safe_float(getattr(cause, "phi", None)) if cause is not None else float("nan"),
        "phi_e": safe_float(getattr(effect, "phi", None)) if effect is not None else float("nan"),
        "i_diff_cause": direction_value(idiff, "CAUSE"),
        "i_diff_effect": direction_value(idiff, "EFFECT"),
        "system_ii": safe_float(getattr(sia, "intrinsic_information", None)),
        "sia_type": type(sia).__name__,
    }


def cycle_decomposition(p: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
    visited = [False] * len(p)
    cycles = []
    for start in range(len(p)):
        if visited[start]:
            continue
        cycle = []
        current = start
        while not visited[current]:
            visited[current] = True
            cycle.append(current)
            current = p[current]
        cycles.append(tuple(cycle))
    return tuple(cycles)


def cycle_type(p: tuple[int, ...]) -> str:
    lengths = sorted((len(c) for c in cycle_decomposition(p)), reverse=True)
    return "+".join(str(x) for x in lengths)


def monad_benchmark() -> dict[str, float]:
    """2026 differentiation--specification benchmark used as a numerical check."""
    f = lambda p: -math.log2(p) - p * math.log2(2.0 * p)
    p_star = float(brentq(f, 0.5000000001, 0.9999999999, xtol=1e-15))
    i_diff = -math.log2(p_star)
    i_spec = p_star * math.log2(2.0 * p_star)
    return {
        "p_star": p_star,
        "intrinsic_differentiation": i_diff,
        "intrinsic_specification": i_spec,
        "intrinsic_information_max": min(i_diff, i_spec),
    }


def run_two_node() -> pd.DataFrame:
    reciprocal = (1, 0)
    self_copy = (0, 1)
    rows = []
    for eta in np.linspace(0.50, 1.00, 101):
        eta = float(eta)
        ana = analytical_n_cycle(2, eta)
        g2 = state_risk_uniform_g2(2, eta)
        hyx = 2.0 * h2(eta)
        mi = 2.0 - hyx
        for name, topology in (("reciprocal", reciprocal), ("self", self_copy)):
            res = analyze(topology, eta)
            target = ana["phi_s"] if name == "reciprocal" else 0.0
            rows.append({
                "model": name,
                "eta": eta,
                "phi_s": res["phi_s"],
                "analytic_phi_s": target,
                "abs_error_phi": abs(float(res["phi_s"]) - target),
                "G2_state_risk_uniform": g2,
                "H_Y_given_X": hyx,
                "mutual_information": mi,
            })
    df = pd.DataFrame(rows)
    df.to_csv(OUTDIR / "two_node_eta_sweep.csv", index=False)
    return df


def run_three_node_permutations() -> pd.DataFrame:
    n = 3
    eta = 0.75
    g2 = state_risk_uniform_g2(n, eta)
    hyx = n * h2(eta)
    mi = n - hyx
    rows = []
    for p in permutations(range(n)):
        p = tuple(p)
        res = analyze(p, eta)
        ctype = cycle_type(p)
        rows.append({
            "eta": eta,
            "source_for_target": str(p),
            "cycle_type": ctype,
            "single_3_cycle": ctype == "3",
            "phi_s": res["phi_s"],
            "G2_state_risk_uniform": g2,
            "H_Y_given_X": hyx,
            "mutual_information": mi,
        })
    df = pd.DataFrame(rows).sort_values(["cycle_type", "source_for_target"]).reset_index(drop=True)
    df.to_csv(OUTDIR / "three_node_all_permutations_eta075.csv", index=False)
    return df


def run_three_cycle_sweep() -> pd.DataFrame:
    cycle = (1, 2, 0)
    identity = (0, 1, 2)
    rows = []
    for eta in np.linspace(0.50, 1.00, 101):
        eta = float(eta)
        ana = analytical_n_cycle(3, eta)
        cyc = analyze(cycle, eta)
        ident = analyze(identity, eta)
        rows.append({
            "eta": eta,
            "analytic_phi_s": ana["phi_s"],
            "pyphi_phi_s": cyc["phi_s"],
            "abs_error_phi_s": abs(float(cyc["phi_s"]) - ana["phi_s"]),
            "analytic_phi_partition": ana["phi_partition"],
            "pyphi_phi_c": cyc["phi_c"],
            "pyphi_phi_e": cyc["phi_e"],
            "analytic_i_diff": ana["i_diff"],
            "pyphi_i_diff_cause": cyc["i_diff_cause"],
            "pyphi_i_diff_effect": cyc["i_diff_effect"],
            "identity_phi_s": ident["phi_s"],
        })
    df = pd.DataFrame(rows)
    df.to_csv(OUTDIR / "three_cycle_eta_sweep.csv", index=False)
    return df


def run_selected_cycle_checks(n: int) -> pd.DataFrame:
    cycle = tuple(list(range(1, n)) + [0])
    if n == 4:
        controls = {
            "identity_1+1+1+1": (0, 1, 2, 3),
            "two_plus_two_2+2": (1, 0, 3, 2),
            "three_plus_one_3+1": (1, 2, 0, 3),
        }
    elif n == 5:
        controls = {
            "identity_1+1+1+1+1": (0, 1, 2, 3, 4),
            "three_plus_two_3+2": (1, 2, 0, 4, 3),
            "four_plus_one_4+1": (1, 2, 3, 0, 4),
        }
    else:
        raise ValueError("n must be 4 or 5")

    star = eta_star(n)
    test_etas = [0.50, 0.75, star, 0.90, 0.99, 1.00]
    rows = []
    for eta in test_etas:
        ana = analytical_n_cycle(n, eta)
        res = analyze(cycle, eta)
        rows.append({
            "topology": f"{n}-cycle",
            "eta": eta,
            "pyphi_phi_s": res["phi_s"],
            "analytic_phi_s": ana["phi_s"],
            "abs_error": abs(float(res["phi_s"]) - ana["phi_s"]),
            "pyphi_phi_c": res["phi_c"],
            "pyphi_phi_e": res["phi_e"],
            "analytic_phi_partition": ana["phi_partition"],
            "pyphi_i_diff_cause": res["i_diff_cause"],
            "analytic_i_diff": ana["i_diff"],
        })

    for name, topology in controls.items():
        res = analyze(topology, 0.75)
        rows.append({
            "topology": name,
            "eta": 0.75,
            "pyphi_phi_s": res["phi_s"],
            "analytic_phi_s": 0.0,
            "abs_error": abs(float(res["phi_s"])),
            "pyphi_phi_c": res["phi_c"],
            "pyphi_phi_e": res["phi_e"],
            "analytic_phi_partition": float("nan"),
            "pyphi_i_diff_cause": res["i_diff_cause"],
            "analytic_i_diff": float("nan"),
        })

    df = pd.DataFrame(rows)
    df.to_csv(OUTDIR / f"{['', '', '', '', 'four', 'five'][n]}_node_cycle_validation.csv", index=False)
    return df


def main() -> None:
    version = getattr(pyphi, "__version__", "unknown")
    print(f"PyPhi version: {version}")
    print(f"Expected version: {EXPECTED_PYPHI_VERSION}")
    print(f"Expected commit: {EXPECTED_PYPHI_COMMIT}")
    if version != EXPECTED_PYPHI_VERSION:
        print("WARNING: PyPhi version differs from the manuscript environment.")

    bench = monad_benchmark()
    pd.DataFrame([bench]).to_csv(OUTDIR / "intrinsic_information_benchmark.csv", index=False)

    two = run_two_node()
    perms3 = run_three_node_permutations()
    cycle3 = run_three_cycle_sweep()
    cycle4 = run_selected_cycle_checks(4)
    cycle5 = run_selected_cycle_checks(5)

    rec = two[two["model"] == "reciprocal"].reset_index(drop=True)
    self_df = two[two["model"] == "self"].reset_index(drop=True)
    eta2 = eta_star(2)
    phi2 = analytical_n_cycle(2, eta2)["phi_s"]
    at075 = rec[np.isclose(rec["eta"], 0.75)].iloc[0]

    single3 = perms3[perms3["single_3_cycle"]]
    multi3 = perms3[~perms3["single_3_cycle"]]
    eta3 = eta_star(3)
    phi3 = analytical_n_cycle(3, eta3)["phi_s"]

    print("\n=== Manuscript checks ===")
    print(f"Monad: p*={bench['p_star']:.12f}, ii_max={bench['intrinsic_information_max']:.12f}")
    print(f"n=2 max |PyPhi-analytic| = {rec['abs_error_phi'].max():.3g}")
    print(f"n=2 max self-copy |phi_s| = {self_df['phi_s'].abs().max():.3g}")
    print(f"n=2 eta*={eta2:.12f}, phi_max={phi2:.12f}")
    print(f"n=2 eta=0.75: phi_s={at075['phi_s']:.12f}, G2={at075['G2_state_risk_uniform']:.12f}")
    print(f"n=3 eta=0.75: single-cycle phi_s={single3['phi_s'].iloc[0]:.12f}, max multicycle |phi_s|={multi3['phi_s'].abs().max():.3g}")
    print(f"n=3 max |PyPhi-analytic| = {cycle3['abs_error_phi_s'].max():.3g}")
    print(f"n=3 eta*={eta3:.12f}, phi_max={phi3:.12f}")
    for n, df in ((4, cycle4), (5, cycle5)):
        cyc = df[df["topology"] == f"{n}-cycle"]
        controls = df[df["topology"] != f"{n}-cycle"]
        e = eta_star(n)
        p = analytical_n_cycle(n, e)["phi_s"]
        print(f"n={n} max |PyPhi-analytic| = {cyc['abs_error'].max():.3g}; max control |phi_s|={controls['pyphi_phi_s'].abs().max():.3g}; eta*={e:.12f}; phi_max={p:.12f}")

    print(f"\nCSV files written to: {OUTDIR}")


if __name__ == "__main__":
    main()
